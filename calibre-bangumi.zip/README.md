# calibre-bangumi
Calibre Bangumi 元数据插件
